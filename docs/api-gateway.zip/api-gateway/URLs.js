module.exports = {
    USER_API_URL: 'http://localhost:5001/',
    ADMIN_API_URL: 'http://localhost:5002/'
  

  };