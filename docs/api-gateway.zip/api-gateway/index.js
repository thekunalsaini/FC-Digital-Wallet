const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const port = 5000;

const {
  USER_API_URL,
  ADMIN_API_URL
 
} = require('./URLs');

const optionsUsers = {
  target: USER_API_URL,
  changeOrigin: true, 
  logger: console,
};

const optionsAdmin = {
  target: ADMIN_API_URL,
  changeOrigin: true, 
  logger: console,
};


const usersProxy = createProxyMiddleware(optionsUsers);
const adminProxy = createProxyMiddleware(optionsAdmin);



app.get('/', (req, res) => res.send('Hello Gateway API'));
app.get('/admin', adminProxy);


// app.post('/', (req, res) => res.send('Hello Gateway API'));
app.post('/users/signup', usersProxy);
app.post('/users/signin', usersProxy);
app.post('/admin/signin', adminProxy);


app.put('/users/:id', usersProxy);
app.put('/admin/:id', adminProxy);


app.delete('/users/:id', usersProxy);
app.delete('/admin/:id', adminProxy);




app.listen(port, () => console.log(`Example app listening on port ${port}!`));